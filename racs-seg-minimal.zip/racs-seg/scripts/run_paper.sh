#!/usr/bin/env bash
# Reproduce the paper experiments: three independent splits per dataset.
# Usage:
#   bash scripts/run_paper.sh lidc  data/              # folder with data_lidc.pickle
#   bash scripts/run_paper.sh riga_cup data/riga_cup.npz
# Results: results/<name>_s{1,2,3} and results/<name>_combined
set -e
NAME=$1; DATA=$2
for S in 1 2 3; do
  python -m racs.train --data "$DATA" --mode sdf  --out "runs/${NAME}_sdf_s${S}"  --seed "$S" --split-seed "$S"
  python -m racs.train --data "$DATA" --mode prob --out "runs/${NAME}_prob_s${S}" --seed "$S" --split-seed "$S"
  python -m racs.evaluate --sdf-run "runs/${NAME}_sdf_s${S}" --prob-run "runs/${NAME}_prob_s${S}" --out "results/${NAME}_s${S}"
done
python -m racs.aggregate results/${NAME}_s1 results/${NAME}_s2 results/${NAME}_s3 --out results/${NAME}_combined
