"""Convert the RIGA dataset (Almazroa et al., SPIE 2018) to the RACS .npz format.

Each RIGA image comes as an original (`imageNprime.*`) and six copies on which
one ophthalmologist each drew the optic disc and optic cup contours
(`imageN-1.*` ... `imageN-6.*`). The contours are recovered as the pixels that
differ from the original, and filled: the disc is the filled outer contour,
the cup the region enclosed by the inner contour.

Output (one file per structure):
  riga_disc.npz, riga_cup.npz with
    images [N, S, S] float32 in [0, 1] (green channel... see --channel)
    masks  [N, 6, S, S] uint8
    groups [N] str (one group per image; RIGA has no patient ids)
    names  [N] str
A crop of side 2.5 x the largest rater disc diameter, centred on the mean
disc, is resized to S x S (default 128).

Usage:
  python scripts/prepare_riga.py --root data/riga --out data --size 128
where data/riga contains the unzipped BinRushed/ and/or Magrabia/ folders.
"""
import argparse, os, re, glob
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

PAT = re.compile(r"^image(\d+)(prime|-(\d))\.(jpg|tif|tiff)$", re.I)


def find_cases(root):
    """Return {case_key: {'prime': path, 1: path, ..., 6: path}}."""
    cases = {}
    for dirpath, _, files in os.walk(root):
        if os.path.basename(dirpath) == "BinRushed1" and \
           os.path.isdir(os.path.join(os.path.dirname(dirpath), "BinRushed1-Corrected")):
            continue  # superseded by the corrected folder
        for f in files:
            m = PAT.match(f)
            if not m:
                continue
            key = os.path.relpath(dirpath, root) + "/image" + m.group(1)
            slot = "prime" if m.group(2).lower() == "prime" else int(m.group(3))
            cases.setdefault(key, {})[slot] = os.path.join(dirpath, f)
    return {k: v for k, v in cases.items()
            if "prime" in v and all(i in v for i in range(1, 7))}


def load_rgb(p):
    return np.asarray(Image.open(p).convert("RGB")).astype(np.int16)


def contour_to_masks(prime, marked, thr=60):
    diff = np.abs(marked - prime).sum(-1) > thr
    if diff.sum() < 50:
        return None
    ys, xs = np.nonzero(diff)
    y0, y1 = max(ys.min() - 5, 0), ys.max() + 6
    x0, x1 = max(xs.min() - 5, 0), xs.max() + 6
    c = diff[y0:y1, x0:x1]
    c = ndi.binary_closing(c, structure=np.ones((3, 3)), iterations=2)
    c = ndi.binary_dilation(c, iterations=1)
    lab, n = ndi.label(~c)
    border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]])))
    holes = [(i, (lab == i).sum()) for i in range(1, n + 1) if i not in border]
    holes = [h for h in holes if h[1] > 30]
    if len(holes) < 2:
        return None
    disc = ndi.binary_fill_holes(c)
    disc = ndi.binary_erosion(disc, iterations=1)  # undo the dilation
    dl, dn = ndi.label(disc)
    if dn > 1:  # keep the largest filled region; stray marks elsewhere are dropped
        sizes = ndi.sum(disc, dl, range(1, dn + 1))
        disc = dl == (1 + int(np.argmax(sizes)))
    # cup: the hole whose filled region does not contain another hole
    holes.sort(key=lambda h: h[1])
    cup_lab = None
    for i, _ in holes:
        filled = ndi.binary_fill_holes(lab == i)
        if not any(filled[lab == j].any() for j, _ in holes if j != i):
            # a hole that is not the ring: the ring's fill contains the cup
            ring_like = any(ndi.binary_fill_holes(lab == j)[lab == i].any()
                            for j, _ in holes if j != i)
            if ring_like:
                cup_lab = i
                break
    if cup_lab is None:
        return None
    cup = ndi.binary_dilation(lab == cup_lab, iterations=2) & disc  # to contour centre
    full_d = np.zeros(diff.shape, bool); full_d[y0:y1, x0:x1] = disc
    full_c = np.zeros(diff.shape, bool); full_c[y0:y1, x0:x1] = cup
    return full_d, full_c


def crop_resize(arr, box, size, order):
    y0, y1, x0, x1 = box
    H, W = arr.shape[:2]
    pad = [(max(-y0, 0), max(y1 - H, 0)), (max(-x0, 0), max(x1 - W, 0))]
    if arr.ndim == 3:
        pad.append((0, 0))
    a = np.pad(arr, pad, mode="constant")
    a = a[y0 + pad[0][0]:y1 + pad[0][0], x0 + pad[1][0]:x1 + pad[1][0]]
    if order == 0:
        return np.asarray(Image.fromarray(a.astype(np.uint8) * 255)
                          .resize((size, size), Image.BILINEAR)) >= 128
    return np.asarray(Image.fromarray(a.astype(np.uint8))
                      .resize((size, size), Image.BICUBIC))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--out", default="data")
    ap.add_argument("--size", type=int, default=128)
    ap.add_argument("--context", type=float, default=2.5)
    ap.add_argument("--channel", default="gray", choices=["gray", "green"])
    ap.add_argument("--preview", default=None, help="save a PNG of a few cases")
    a = ap.parse_args()
    cases = find_cases(a.root)
    print(f"found {len(cases)} complete cases")
    imgs, discs, cups, names, skipped = [], [], [], [], []
    for key in sorted(cases):
        v = cases[key]
        prime = load_rgb(v["prime"])
        res = []
        for k in range(1, 7):
            m = load_rgb(v[k])
            if m.shape != prime.shape:
                res = None; break
            r = contour_to_masks(prime, m)
            if r is None:
                res = None; break
            res.append(r)
        if res is None:
            skipped.append(key); continue
        d = np.stack([r[0] for r in res]); c = np.stack([r[1] for r in res])
        ys, xs = np.nonzero(d.mean(0) >= 0.5)
        cy, cx = (ys.min() + ys.max()) / 2, (xs.min() + xs.max()) / 2
        side = int(a.context * max(ys.max() - ys.min(), xs.max() - xs.min()))
        box = (int(cy - side / 2), int(cy - side / 2) + side,
               int(cx - side / 2), int(cx - side / 2) + side)
        rgb = crop_resize(prime.astype(np.uint8), box, a.size, 1)
        if a.channel == "green":
            g = rgb[..., 1].astype(np.float32)
        else:
            g = rgb.astype(np.float32) @ np.array([0.299, 0.587, 0.114], np.float32)
        g = (g - g.min()) / max(g.max() - g.min(), 1e-6)
        imgs.append(g.astype(np.float32))
        discs.append(np.stack([crop_resize(x, box, a.size, 0) for x in d]).astype(np.uint8))
        cups.append(np.stack([crop_resize(x, box, a.size, 0) for x in c]).astype(np.uint8))
        names.append(key)
        if len(names) % 25 == 0:
            print(f"  {len(names)} done")
    print(f"converted {len(names)}, skipped {len(skipped)}: {skipped[:10]}")
    images = np.stack(imgs); names = np.array(names)
    groups = names.copy()
    os.makedirs(a.out, exist_ok=True)
    for tag, M in (("disc", discs), ("cup", cups)):
        M = np.stack(M)
        p = os.path.join(a.out, f"riga_{tag}.npz")
        np.savez_compressed(p, images=images, masks=M, groups=groups, names=names)
        area = M.reshape(len(M), 6, -1).sum(-1).astype(float)
        inter = M.min(1).reshape(len(M), -1).sum(-1); union = M.max(1).reshape(len(M), -1).sum(-1)
        print(f"{p}: {M.shape}, mean area {area.mean():.0f} px, "
              f"mean IoU(all raters) {np.mean(inter / np.maximum(union, 1)):.3f}")
    if a.preview:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        n = min(6, len(images))
        fig, ax = plt.subplots(2, n, figsize=(2.2 * n, 4.6))
        for i in range(n):
            j = i * len(images) // n
            for r, M in enumerate((discs, cups)):
                ax[r, i].imshow(images[j], cmap="gray")
                ax[r, i].imshow(M[j].mean(0), cmap="magma", alpha=0.5, vmin=0, vmax=1)
                ax[r, i].set_title(names[j].split("/")[-2] + " " + names[j].split("/")[-1], fontsize=7)
                ax[r, i].axis("off")
        plt.tight_layout(); plt.savefig(a.preview, dpi=120)


if __name__ == "__main__":
    main()
