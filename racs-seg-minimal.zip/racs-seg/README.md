# RACS: Rater-Aware Conformal Segmentation

Code for the paper *Rater-aware conformal calibration keeps medical image segmentation risk guarantees valid for individual experts*.

RACS returns an inner and an outer boundary for each image and controls their error with respect to the experts who annotated the data, not a single consensus mask.

- A U-Net predicts, per pixel, the mean `m` and the spread `s` over raters of the truncated signed distance to the lesion boundary.
- The score `t = m / s` defines nested sets: outer `{t <= λ_out}`, inner `{t < -λ_in}`.
- `λ_out` and `λ_in` are calibrated by conformal risk control with a loss averaged over the raters of each patient, with the patient as the exchangeable unit.

**Guarantee** (finite-sample, distribution-free, under exchangeability of patients): for a new patient and a randomly chosen rater, the expected fraction of the rater's mask missed by the outer set is at most `α_out`, and the expected area of the inner set not marked by the rater, relative to the point prediction, is at most `α_in`. With the max aggregator the bound holds for the worst rater.

## Main results

Three independent splits per dataset, 100 calibration/test repartitions per split, target α = 0.10.

| | LIDC-IDRI (4 raters, 875 scans) | RIGA optic cup (6 raters, 277 images) |
|:--|:-:|:-:|
| Rater-aware calibration: outer / inner risk | 0.093 / 0.089 | 0.083 / 0.083 |
| Majority-vote calibration: outer / inner risk | 0.110 / **0.125** | 0.109 / **0.141** |
| STAPLE calibration: outer / inner risk | 0.110 / **0.125** | 0.069 / **0.211** |
| Band, RACS vs sub-pixel dilation | 15% smaller | 9% larger |

Consensus calibration exceeded α in 58 of 60 configurations (5 set families × 3 levels × 2 consensus rules × 2 datasets); rater-aware calibration never did. Full tables are in the paper and its Supplementary Information.

## Install

```bash
pip install -r requirements.txt
python -m pytest -q tests        # 14 tests
```

## Quick check on synthetic data (CPU, a few minutes)

```bash
python -m racs.train --data synthetic --mode sdf  --out runs/syn_sdf  --epochs 45 --base 16 --depth 3
python -m racs.train --data synthetic --mode prob --out runs/syn_prob --epochs 30 --base 16 --depth 3
python -m racs.evaluate --sdf-run runs/syn_sdf --prob-run runs/syn_prob --out results/syn
python -m racs.report results/syn
```

## Data

**LIDC-IDRI.** The loader reads the preprocessed 2D crops distributed with [Probabilistic-Unet-Pytorch](https://github.com/stefanknegt/Probabilistic-Unet-Pytorch) (`data_lidc.pickle`, 15,096 crops of 128 × 128 pixels, 4 raters each). Put the file in `data/`. Crops are grouped by `series_uid` (one unit per CT scan). Publications must cite LIDC-IDRI and TCIA and include their acknowledgement statement.

**RIGA.** Download `BinRushedcorrected.zip` and `Magrabia.zip` from [Deep Blue Data](https://doi.org/10.7302/Z23R0R29), unzip them into `data/riga/` and run

```bash
python scripts/prepare_riga.py --root data/riga --out data --preview data/riga_preview.png
```

This writes `data/riga_cup.npz` and `data/riga_disc.npz` (128 × 128 crops centred on the optic disc, 6 masks each; 277 of 289 images converted). RIGA may be used for research free of charge but **not redistributed**: never commit the `.npz` files. Cite Almazroa et al., Proc. SPIE 10579, 105790B (2018), and acknowledge the MESSIDOR program, Magrabi Eye Center and Bin Rushed Ophthalmic Center.

**Other datasets.** Save any multi-rater dataset as

```python
np.savez("mydata.npz", images=images, masks=masks, groups=groups)
# images float [N, H, W] in [0, 1]; masks [N, K, H, W] binary; groups [N] patient ids
```

and pass `--data mydata.npz`. Height and width must be divisible by `2 ** depth`.

## Reproducing the paper

```bash
bash scripts/run_paper.sh lidc data/                 # three splits + combined tables
bash scripts/run_paper.sh riga_cup data/riga_cup.npz
```

Each split trains two networks for 100 epochs. On one NVIDIA T4 GPU a RIGA epoch takes about 1 s. `notebooks/RACS_Colab.ipynb` runs the same pipeline on Google Colab with checkpoints on Google Drive; training resumes automatically after a disconnect.

The truncation distance `D = 4` and the signed outer parameter were fixed on a development split of LIDC-IDRI (split seed 0) that is not used for any reported number.

## Repository layout

| Path | Content |
|:--|:--|
| `racs/data.py` | Signed distances, rater statistics, data loaders, splits, augmentation |
| `racs/model.py`, `racs/losses.py`, `racs/train.py` | U-Net, β-NLL and Dice/BCE losses, training with automatic resume |
| `racs/sets.py` | Scores of all set families and prediction of nested sets |
| `racs/calibrate.py` | Loss curves and conformal risk control on a grid |
| `racs/metrics.py` | Dice, majority vote, STAPLE |
| `racs/evaluate.py`, `racs/report.py`, `racs/aggregate.py`, `racs/figures.py` | Evaluation protocol, console report, combination of splits, figures |
| `scripts/` | RIGA conversion and run scripts |
| `tests/` | Unit tests |

## What `evaluate` writes


| File | Content |
|---|---|
| (console) | `python -m racs.report <folder>` prints a compact table |
| (combined) | `python -m racs.aggregate <folder1> <folder2> ... --out <dir>` combines splits into tables (Markdown, LaTeX) and figures |
| `summary.md` | Tables of test risk, band size and alignment per method and calibration target |
| `results.csv`, `results_raw.csv` | Mean ± std over repartitions, and every repartition |
| `lambdas.json` | Calibrated `λ_out`, `λ_in` on the original split, for deployment |
| `paired_tests.csv` | Wilcoxon test of per-unit band area, RACS vs each baseline |
| `ablation_ncal.csv` | Risk and band size versus number of calibration units |
| `stats.json` | Dataset statistics, base Dice, spread correlation |
| `fig_*.png` | Validity, calibration-target, efficiency and qualitative figures |

Set families: `racs` (proposed), `racs_s1` (spread fixed to 1), `prob`
(threshold on a baseline network's probability), `dilation` (uniform dilation
and erosion of the baseline mask), `dilation_sub` (the same in sub-pixel
steps).
Calibration targets: `raters_mean`, `raters_max` (rater-aware), `majority`,
`staple`, `one_rater` (single-mask baselines).

## Using a calibrated model

```python
import json, torch
from racs.evaluate import load_run
from racs.sets import predict_sets

model, cfg = load_run("runs/lidc_sdf_s1", "cpu")
lam = json.load(open("results/lidc_s1/lambdas.json"))["racs|raters_mean|0.1"]
out = predict_sets(model, image, lam["lambda_out"], lam["lambda_in"],
                   D=cfg["D"], s_min=cfg["s_min"])
inner, outer, band = out["inner"], out["outer"], out["band"]
```

## Implementation notes

- **Exchangeable unit.** Slices of one patient are dependent. By default the
  loss of a patient is the average over that patient's images, and patients
  are the units of calibration (`--unit patient`). The guarantee is then on
  the patient-averaged loss.
- **Outer set may shrink.** `λ_out` is calibrated on `[-λ_max, λ_max]`. When
  the risk budget allows, the outer set moves inside the point prediction.
  `λ_out` is then raised to at least `-λ_in` so the inner set stays inside
  the outer set; this can only lower the outer loss. `--no-signed-outer`
  restores `λ_out >= 0`.
- **Truncation distance.** `--D` defaults to 4 pixels. With a large value, a
  rater who marked nothing dominates the mean signed distance.
- **Grid calibration.** `λ` is searched on a fixed grid of 300 values ending
  at `λ_max`. The guarantee is unchanged; the chosen `λ` is at most one grid
  step larger than the exact solution.
- **Model selection** uses the plain Gaussian NLL on a validation fold taken
  from the training patients. Calibration and test patients are never used
  in training.
- **Rater statistics.** Training needs only the per-pixel mean and variance
  of the raters' signed distances, since
  `mean_k (φ_k − m)² = (m − μ)² + σ²`.


## Citation

If you use this code, please cite the paper (see `CITATION.cff`; details will be added on publication).

## License

MIT. See `LICENSE`.
