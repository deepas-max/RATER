import numpy as np
import pytest
from scipy.ndimage import binary_dilation

from racs import calibrate as C
from racs.data import make_synthetic, signed_distance, split_groups, rater_stats
from racs.metrics import majority_vote, staple
from racs.sets import dilation_score, subpixel_dilation_score


def disk(shape=(40, 40), c=(20, 20), r=8):
    yy, xx = np.mgrid[:shape[0], :shape[1]]
    return (yy - c[0]) ** 2 + (xx - c[1]) ** 2 <= r ** 2


def test_signed_distance_sign_and_truncation():
    m = disk()
    phi = signed_distance(m, D=5)
    assert (phi[m] < 0).all() and (phi[~m] > 0).all()
    assert phi.min() >= -5 and phi.max() <= 5
    assert (signed_distance(np.zeros((8, 8)), 5) == 5).all()
    assert (signed_distance(np.ones((8, 8)), 5) == -5).all()


def test_rater_stats_identity():
    """mean_k (phi_k - m)^2 == (m - mu)^2 + var, for any m."""
    _, masks, _ = make_synthetic(n_patients=2, per_patient=1, size=32)
    mu, var, _ = rater_stats(masks, D=20)
    phi = np.stack([signed_distance(mk, 20) for mk in masks[0]])
    m = np.random.default_rng(0).normal(size=phi.shape[1:])
    lhs = ((phi - m) ** 2).mean(0)
    rhs = (m - mu[0].astype(np.float64)) ** 2 + var[0].astype(np.float64)
    # statistics are stored as float16, hence the loose tolerance
    assert np.allclose(lhs, rhs, rtol=3e-3, atol=0.05)


def test_dilation_score_matches_morphology():
    m = disk(r=6)
    t = dilation_score(m)
    for lam in (1, 2, 3, 5):
        yy, xx = np.mgrid[-lam:lam + 1, -lam:lam + 1]
        se = yy ** 2 + xx ** 2 <= lam ** 2
        assert np.array_equal(t <= lam, binary_dilation(m, structure=se))


def test_sets_are_nested():
    rng = np.random.default_rng(0)
    t = rng.normal(size=(32, 32)) * 3
    y0 = t < 0
    prev_o, prev_i = None, None
    for lam in np.linspace(0, 10, 25):
        o, i = t <= lam, t < -lam
        assert (i <= y0).all() and (y0 <= o).all()
        if prev_o is not None:
            assert (prev_o <= o).all() and (i <= prev_i).all()
        prev_o, prev_i = o, i


def test_loss_curves_match_brute_force():
    rng = np.random.default_rng(1)
    t = np.clip(rng.normal(size=(24, 24)) * 4, -10, 10)
    y = disk((24, 24), (12, 12), 6)
    grid = C.lambda_grid(10.0, 50)
    lo, li = C.outer_loss_curve(t, y, grid), C.inner_loss_curve(t, y, grid)
    for g, lam in enumerate(grid):
        o, i = t <= lam, t < -lam
        assert np.isclose(lo[g], (y & ~o).sum() / y.sum())
        assert np.isclose(li[g], (i & ~y).sum() / (t < 0).sum())
        assert C.outer_count_curve(t, grid)[g] == o.sum()
        assert C.inner_count_curve(t, grid)[g] == i.sum()
    assert (np.diff(lo) <= 0).all() and (np.diff(li) <= 0).all()
    assert lo[-1] == 0 and li[-1] == 0 and lo.max() <= 1 and li.max() <= 1


def test_empty_mask_and_empty_prediction():
    grid = C.lambda_grid(5.0, 20)
    t = np.full((8, 8), 3.0)
    y = np.zeros((8, 8), bool)
    assert (C.outer_loss_curve(t, y, grid) == 0).all()
    assert (C.inner_loss_curve(t, y, grid) == 0).all()


def test_crc_requires_enough_calibration_units():
    L = np.zeros((9, 5))
    with pytest.raises(ValueError):
        C.crc_index(L, alpha=0.05)
    assert C.crc_index(L, alpha=0.1) == 0


def _random_units(rng, n, grid, K=3, size=16):
    """Random score maps and rater masks; returns mean-aggregated outer loss."""
    out = np.empty((n, len(grid)))
    for i in range(n):
        base = rng.normal(size=(size, size)).cumsum(0).cumsum(1) / 6
        t = np.clip(base + rng.normal(size=base.shape), -grid[-1], grid[-1])
        ys = [(base + rng.normal(0, 1.5) + rng.normal(size=base.shape)) < 0
              for _ in range(K)]
        out[i] = C.aggregate(
            np.stack([C.outer_loss_curve(t, y, grid) for y in ys]), "mean")
    return out


def test_crc_controls_risk_on_average():
    """Monte Carlo check of Theorem 1: E[test loss] <= alpha."""
    rng = np.random.default_rng(0)
    grid = C.lambda_grid(30.0, 200)
    pool = _random_units(rng, 600, grid)
    n, alpha, trials = 40, 0.1, 3000
    losses = np.empty(trials)
    for k in range(trials):
        idx = rng.choice(len(pool), n + 1, replace=False)
        g = C.crc_index(pool[idx[:n]], alpha)
        losses[k] = pool[idx[n], g]
    se = losses.std() / np.sqrt(trials)
    assert losses.mean() <= alpha + 3 * se
    assert losses.mean() >= alpha - 2 / (n + 1) - 0.03   # not vacuous


def test_staple_and_majority_on_identical_raters():
    m = disk()
    masks = np.stack([m, m, m, m])
    assert np.array_equal(staple(masks), m)
    assert np.array_equal(majority_vote(masks), m)
    assert not staple(np.zeros((3, 8, 8), bool)).any()


def test_staple_downweights_an_outlier_rater():
    m = disk()
    masks = np.stack([m, m, m, ~m])
    assert np.array_equal(staple(masks), m)


def test_split_groups_is_disjoint_and_complete():
    groups = np.repeat(np.arange(50), 3)
    s1 = split_groups(groups, seed=0)
    s2 = split_groups(groups, seed=0)
    seen = np.concatenate(list(s1.values()))
    assert sorted(seen) == list(range(len(groups)))
    parts = [set(groups[v]) for v in s1.values()]
    for a in range(4):
        for b in range(a + 1, 4):
            assert not parts[a] & parts[b]
    assert all(np.array_equal(s1[k], s2[k]) for k in s1)


def test_signed_grid_and_nested_outer():
    g = C.lambda_grid(10.0, 50)
    og = C.signed_grid(g)
    assert len(og) == 2 * len(g) - 1 and (np.diff(og) > 0).all()
    assert og[0] == -10.0 and og[-1] == 10.0 and og[len(g) - 1] == 0.0
    rng = np.random.default_rng(3)
    t = np.clip(rng.normal(size=(24, 24)) * 4, -10, 10)
    y = disk((24, 24), (12, 12), 6)
    lo = C.outer_loss_curve(t, y, og)
    assert (np.diff(lo) <= 0).all() and lo[-1] == 0 and lo.max() <= 1
    for k, lam in enumerate(og):
        assert np.isclose(lo[k], (y & ~(t <= lam)).sum() / y.sum())
    # whatever the calibrated outer index, the inner set stays inside the outer set
    for gi in (0, 5, 20, 49):
        for go in (0, 10, 49, 80):
            go2 = C.nested_outer_index(og, go, g[gi])
            assert go2 >= go
            assert ((t < -g[gi]) <= (t <= og[go2])).all()
    # unsigned outer grid: constraint is never active
    assert C.nested_outer_index(g, 0, g[20]) == 0


def test_crc_controls_risk_with_signed_outer():
    rng = np.random.default_rng(1)
    og = C.signed_grid(C.lambda_grid(30.0, 150))
    pool = _random_units(rng, 600, og)
    n, alpha, trials = 40, 0.2, 3000
    losses = np.empty(trials)
    for k in range(trials):
        idx = rng.choice(len(pool), n + 1, replace=False)
        losses[k] = pool[idx[n], C.crc_index(pool[idx[:n]], alpha)]
    assert losses.mean() <= alpha + 3 * losses.std() / np.sqrt(trials)
    assert losses.mean() >= alpha - 0.05


def test_subpixel_dilation_score():
    m = disk(r=8)
    logit = np.where(m, 3.0, -3.0)
    t = subpixel_dilation_score(logit)
    whole = dilation_score(m)
    assert t.shape == m.shape
    assert ((t < 0) == m).all()                      # same point prediction
    assert np.abs(t - whole).max() <= 1.0            # same geometry, finer steps
    assert len(np.unique(np.round(t, 3))) > len(np.unique(whole))
    lam = np.hypot(*m.shape)
    assert (subpixel_dilation_score(np.full((8, 8), -1.0)) == np.hypot(8, 8)).all()
    assert (subpixel_dilation_score(np.full((8, 8), 1.0)) == -np.hypot(8, 8)).all()
