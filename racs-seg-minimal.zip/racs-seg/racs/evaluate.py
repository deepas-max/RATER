"""Evaluation protocol: validity, efficiency and alignment of prediction sets.

    python -m racs.evaluate --sdf-run runs/lidc_sdf_s0 \
        --prob-run runs/lidc_prob_s0 --out results/lidc_s0

Set families (methods)
    racs      studentized signed distance m / s            (proposed)
    racs_s1   same network, spread fixed to 1              (ablation)
    prob      threshold on the baseline probability        (baseline B1)
    dilation  uniform dilation / erosion of the baseline   (baseline B2)
    dilation_sub  the same in sub-pixel steps              (baseline B2, finer)

Calibration targets
    raters_mean  rater-aware, mean over raters             (proposed)
    raters_max   rater-aware, worst rater                  (proposed)
    majority     single majority-vote mask                 (baseline B4)
    staple       single STAPLE mask                        (baseline B4)
    one_rater    single randomly chosen rater              (baseline B4)

Whatever the calibration target, the reported test risks are the rater-aware
ones: `risk_out_mean` is the expected miss fraction for a random rater.
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np
import pandas as pd
import torch
from scipy.stats import spearmanr, wilcoxon

from . import calibrate as C
from .data import load_dataset, signed_distance, split_groups
from .metrics import dice, majority_vote, staple
from .model import UNet, sdf_head
from .sets import (dilation_score, lam_max_of, prob_score, racs_score,
                   subpixel_dilation_score)

METHODS = ["racs", "racs_s1", "prob", "dilation", "dilation_sub"]
TARGETS = ["raters_mean", "raters_max", "majority", "staple", "one_rater"]
GRID_POWER = {"racs": 3.0, "racs_s1": 2.0, "prob": 2.0, "dilation": 3.0,
              "dilation_sub": 3.0}


def get_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument("--sdf-run", required=True)
    p.add_argument("--prob-run", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--data", default=None,
                   help="defaults to the dataset recorded in the sdf run")
    p.add_argument("--alphas", type=float, nargs="+", default=[0.05, 0.1, 0.2])
    p.add_argument("--reps", type=int, default=100,
                   help="random calibration / test repartitions")
    p.add_argument("--unit", choices=["patient", "image"], default="patient",
                   help="exchangeable unit; 'patient' averages the loss over "
                        "the images of one patient")
    p.add_argument("--grid", type=int, default=300)
    p.add_argument("--no-signed-outer", action="store_true",
                   help="keep the outer set outside the point prediction "
                        "(lambda_out >= 0), as in the first version")
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--no-figures", action="store_true")
    return p.parse_args(argv)


def load_run(run_dir, device):
    ck = torch.load(os.path.join(run_dir, "ckpt_best.pt"),
                    map_location=device, weights_only=False)
    cfg = ck["cfg"]
    out_ch = 2 if cfg["mode"] == "sdf" else 1
    model = UNet(1, out_ch, cfg["base"], cfg["depth"]).to(device)
    model.load_state_dict(ck["model"])
    return model.eval(), cfg


@torch.no_grad()
def infer(sdf_model, prob_model, images, cfg, device, batch_size=64):
    """Yield (index, m, s, logit) as float64 arrays, one image at a time."""
    for a in range(0, len(images), batch_size):
        x = torch.from_numpy(images[a:a + batch_size])[:, None].to(device)
        m, s = sdf_head(sdf_model(x).float(), cfg["D"], cfg["s_min"])
        logit = prob_model(x)[:, 0].float()
        m, s, logit = (v.cpu().numpy().astype(np.float64)
                       for v in (m, s, logit))
        for j in range(len(m)):
            yield a + j, m[j], s[j], logit[j]


def score_maps(m, s, logit):
    return {
        "racs": racs_score(m, s),
        "racs_s1": m,
        "prob": prob_score(logit),
        "dilation": dilation_score(logit > 0),
        "dilation_sub": subpixel_dilation_score(logit),
    }


def build_curves(sdf_model, prob_model, images, masks, cfg, grids, ogrids,
                 device, batch_size, seed):
    """Loss and size curves of every image along each method's lambda grid."""
    N, K = masks.shape[:2]
    rng = np.random.default_rng(seed)
    pick = rng.integers(K, size=N)
    keys = ([f"{side}_{t}" for side in ("out", "in") for t in TARGETS]
            + ["cntO", "cntI", "disO", "disI"])
    curves = {m: {k: np.zeros((N, len(ogrids[m]) if k.startswith(("out_", "cntO", "disO"))
                              else len(grids[m])), np.float32) for k in keys}
              for m in METHODS}
    info = {k: np.zeros(N) for k in
            ["union", "ndis", "area", "dice_sdf", "dice_prob", "spearman"]}
    info["spearman"][:] = np.nan

    for i, m, s, logit in infer(sdf_model, prob_model, images, cfg, device,
                                batch_size):
        y = masks[i].astype(bool)
        single = {"majority": majority_vote(y), "staple": staple(y),
                  "one_rater": y[pick[i]]}
        union, inter = y.any(0), y.all(0)
        dis = union & ~inter
        info["union"][i], info["ndis"][i] = union.sum(), dis.sum()
        info["area"][i] = y.sum((1, 2)).mean()
        info["dice_sdf"][i] = np.mean([dice(m < 0, yk) for yk in y])
        info["dice_prob"][i] = np.mean([dice(logit > 0, yk) for yk in y])

        near = np.abs(m) <= 2.0
        if near.sum() >= 20:
            phi = np.stack([signed_distance(yk, cfg["D"]) for yk in y])
            emp = phi.std(0)[near]
            if emp.std() > 0 and s[near].std() > 0:
                info["spearman"][i] = spearmanr(s[near], emp)[0]

        for name, t in score_maps(m, s, logit).items():
            g, og, cv = grids[name], ogrids[name], curves[name]
            t = np.clip(t, -g[-1], g[-1])
            out = np.stack([C.outer_loss_curve(t, yk, og) for yk in y])
            inn = np.stack([C.inner_loss_curve(t, yk, g) for yk in y])
            cv["out_raters_mean"][i] = C.aggregate(out, "mean")
            cv["out_raters_max"][i] = C.aggregate(out, "max")
            cv["in_raters_mean"][i] = C.aggregate(inn, "mean")
            cv["in_raters_max"][i] = C.aggregate(inn, "max")
            for tname, ym in single.items():
                cv[f"out_{tname}"][i] = C.outer_loss_curve(t, ym, og)
                cv[f"in_{tname}"][i] = C.inner_loss_curve(t, ym, g)
            cv["cntO"][i] = C.outer_count_curve(t, og)
            cv["cntI"][i] = C.inner_count_curve(t, g)
            cv["disO"][i] = C.outer_count_curve(t, og, dis)
            cv["disI"][i] = C.inner_count_curve(t, g, dis)
    return curves, info


def unit_means(arr, unit, n_units):
    """Average rows of `arr` [N, ...] within each unit."""
    order = np.argsort(unit, kind="stable")
    starts = np.searchsorted(unit[order], np.arange(n_units))
    sums = np.add.reduceat(arr[order], starts, axis=0)
    counts = np.bincount(unit, minlength=n_units)
    return sums / counts.reshape(-1, *([1] * (arr.ndim - 1)))


def evaluate_split(cal_u, test_u, U, curves, info, unit, w_img, tert, alphas,
                   grids, ogrids, methods=METHODS, targets=TARGETS):
    """Calibrate on `cal_u` units, test on `test_u` units. Returns rows."""
    n = len(cal_u)
    test_img = np.isin(unit, test_u)
    w = w_img[test_img] / len(test_u)
    ndis = info["ndis"][test_img]
    union_mean = info["union"][test_img] @ w
    rows = []
    for m in methods:
        cv, Um = curves[m], U[m]
        for tg in targets:
            cal_out = Um[f"out_{tg}"][cal_u].mean(0)
            cal_in = Um[f"in_{tg}"][cal_u].mean(0)
            for a in alphas:
                gi = C.crc_index_from_mean(cal_in, n, a)
                go = C.crc_index_from_mean(cal_out, n, a)
                go = C.nested_outer_index(ogrids[m], go, grids[m][gi])
                band = cv["cntO"][test_img, go] - cv["cntI"][test_img, gi]
                hit = cv["disO"][test_img, go] - cv["disI"][test_img, gi]
                den = band + ndis
                bdice = np.where(den > 0, 2 * hit / np.maximum(den, 1), 1.0)
                row = {
                    "method": m, "target": tg, "alpha": a,
                    "g_out": go, "g_in": gi,
                    "risk_out_mean": Um["out_raters_mean"][test_u, go].mean(),
                    "risk_out_max": Um["out_raters_max"][test_u, go].mean(),
                    "risk_in_mean": Um["in_raters_mean"][test_u, gi].mean(),
                    "risk_in_max": Um["in_raters_max"][test_u, gi].mean(),
                    "band_px": band @ w,
                    "band_rel": (band @ w) / max(union_mean, 1e-9),
                    "band_dice": bdice @ w,
                    # share of the band inside the region raters disagree on,
                    # and share of that region covered by the band
                    "band_prec": (hit @ w) / max(band @ w, 1e-9) if (band @ w) > 0 else np.nan,
                    "band_rec": (hit @ w) / max(ndis @ w, 1e-9),
                }
                lo = cv["out_raters_mean"][:, go]
                for name, sel in tert.items():
                    sel = sel & test_img
                    row[f"risk_out_{name}"] = lo[sel].mean() if sel.any() else np.nan
                rows.append(row)
    return rows


def main(argv=None):
    args = get_args(argv)
    os.makedirs(args.out, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    sdf_model, cfg = load_run(args.sdf_run, device)
    prob_model, pcfg = load_run(args.prob_run, device)
    assert cfg["mode"] == "sdf" and pcfg["mode"] == "prob"
    assert cfg["split_seed"] == pcfg["split_seed"], "runs use different splits"

    images, masks, groups = load_dataset(args.data or cfg["data"])
    split = split_groups(groups, seed=cfg["split_seed"])
    pool = np.concatenate([split["cal"], split["test"]])
    images, masks, groups = images[pool], masks[pool], groups[pool]
    is_cal_img = np.arange(len(pool)) < len(split["cal"])
    shape = images.shape[1:]

    grids = {m: C.lambda_grid(lam_max_of(m, shape, cfg["D"], cfg["s_min"]),
                              args.grid, GRID_POWER[m]) for m in METHODS}
    print(f"[eval] computing curves for {len(images)} images on {device}")
    ogrids = {m: (g if args.no_signed_outer else C.signed_grid(g))
              for m, g in grids.items()}
    curves, info = build_curves(sdf_model, prob_model, images, masks, cfg,
                                grids, ogrids, device, args.batch_size, args.seed)

    # ---- exchangeable units -------------------------------------------
    if args.unit == "patient":
        _, unit = np.unique(groups, return_inverse=True)
    else:
        unit = np.arange(len(images))
    n_units = unit.max() + 1
    w_img = 1.0 / np.bincount(unit)[unit]
    U = {m: {k: unit_means(v, unit, n_units) for k, v in curves[m].items()
             if k.startswith(("out_", "in_"))} for m in METHODS}
    cal_units = np.unique(unit[is_cal_img])
    test_units = np.unique(unit[~is_cal_img])
    n_cal = len(cal_units)
    print(f"[eval] unit={args.unit}: {n_cal} calibration, "
          f"{len(test_units)} test units")

    pos = info["union"] > 0
    q1, q2 = np.quantile(info["area"][pos], [1 / 3, 2 / 3])
    tert = {"small": pos & (info["area"] <= q1),
            "medium": pos & (info["area"] > q1) & (info["area"] <= q2),
            "large": pos & (info["area"] > q2)}

    # ---- random repartitions ------------------------------------------
    rng = np.random.default_rng(args.seed)
    rows = []
    for r in range(args.reps):
        perm = rng.permutation(n_units)
        for row in evaluate_split(perm[:n_cal], perm[n_cal:], U, curves, info,
                                  unit, w_img, tert, args.alphas, grids, ogrids):
            row["rep"] = r
            rows.append(row)
    raw = pd.DataFrame(rows)
    for side in ("out", "in"):
        lam = np.empty(len(raw))
        for m in METHODS:
            sel = (raw["method"] == m).to_numpy()
            gg = ogrids[m] if side == "out" else grids[m]
            lam[sel] = gg[raw.loc[sel, f"g_{side}"].to_numpy()]
        raw[f"lambda_{side}"] = lam
    raw.to_csv(os.path.join(args.out, "results_raw.csv"), index=False)
    value_cols = [c for c in raw.columns
                  if c not in ("method", "target", "alpha", "rep", "g_out", "g_in")]
    summary = raw.groupby(["method", "target", "alpha"])[value_cols].agg(["mean", "std"])
    summary.columns = [f"{a}_{b}" for a, b in summary.columns]
    summary = summary.reset_index()
    summary.to_csv(os.path.join(args.out, "results.csv"), index=False)

    # ---- original split: lambdas for deployment, paired test ------------
    orig = pd.DataFrame(evaluate_split(cal_units, test_units, U, curves, info,
                                       unit, w_img, tert, args.alphas,
                                       grids, ogrids))
    lambdas = {}
    for _, r in orig[orig["target"].isin(["raters_mean", "raters_max"])].iterrows():
        lambdas[f"{r['method']}|{r['target']}|{r['alpha']}"] = {
            "lambda_out": float(ogrids[r["method"]][int(r["g_out"])]),
            "lambda_in": float(grids[r["method"]][int(r["g_in"])])}
    with open(os.path.join(args.out, "lambdas.json"), "w") as f:
        json.dump(lambdas, f, indent=1)

    a_mid = args.alphas[len(args.alphas) // 2]
    test_img = np.isin(unit, test_units)

    def unit_band(method):
        r = orig[(orig.method == method) & (orig.target == "raters_mean")
                 & (orig.alpha == a_mid)].iloc[0]
        band = (curves[method]["cntO"][:, int(r.g_out)]
                - curves[method]["cntI"][:, int(r.g_in)]).astype(np.float64)
        return unit_means(band, unit, n_units)[test_units]

    tests = []
    ref = unit_band("racs")
    for m in METHODS[1:]:
        other = unit_band(m)
        try:
            pval = float(wilcoxon(ref, other).pvalue)
        except ValueError:
            pval = float("nan")
        tests.append({"alpha": a_mid, "baseline": m,
                      "racs_band_px": ref.mean(), "baseline_band_px": other.mean(),
                      "wilcoxon_p": pval, "n_units": len(ref)})
    pd.DataFrame(tests).to_csv(os.path.join(args.out, "paired_tests.csv"), index=False)

    # ---- calibration-size ablation --------------------------------------
    sizes = [n for n in (25, 50, 100, 250, 500, 1000) if n < n_cal] + [n_cal]
    sizes = [n for n in sizes if a_mid >= 1 / (n + 1)]
    abl = []
    for r in range(args.reps):
        perm = rng.permutation(n_units)
        for n in sizes:
            for row in evaluate_split(perm[:n], perm[n_cal:], U, curves, info,
                                      unit, w_img, tert, [a_mid], grids, ogrids,
                                      methods=["racs"], targets=["raters_mean"]):
                abl.append({"n_cal": n, "rep": r,
                            "risk_out_mean": row["risk_out_mean"],
                            "risk_in_mean": row["risk_in_mean"],
                            "band_px": row["band_px"]})
    abl = pd.DataFrame(abl).drop(columns="rep").groupby("n_cal").agg(["mean", "std"])
    abl.columns = [f"{a}_{b}" for a, b in abl.columns]
    abl.reset_index().to_csv(os.path.join(args.out, "ablation_ncal.csv"), index=False)

    # ---- descriptive statistics -----------------------------------------
    stats = {
        "n_images": int(len(images)), "n_cal_units": int(n_cal),
        "n_test_units": int(len(test_units)), "unit": args.unit,
        "raters": int(masks.shape[1]),
        "signed_outer": not args.no_signed_outer,
        "D": cfg["D"],
        "empty_mask_fraction": float((masks.sum((2, 3)) == 0).mean()),
        "dice_sdf_network": float(info["dice_sdf"].mean()),
        "dice_prob_network": float(info["dice_prob"].mean()),
        "spread_spearman_mean": float(np.nanmean(info["spearman"])),
        "spread_spearman_n": int(np.isfinite(info["spearman"]).sum()),
    }
    with open(os.path.join(args.out, "stats.json"), "w") as f:
        json.dump(stats, f, indent=1)

    write_summary(args.out, summary, stats, tests, args.alphas)
    if not args.no_figures:
        from .figures import make_figures
        make_figures(args.out, summary, args.alphas, images, masks,
                     sdf_model, prob_model, cfg, lambdas, min(args.alphas), device,
                     np.flatnonzero(test_img), info)
    print(f"[eval] wrote results to {args.out}")


def write_summary(out, summary, stats, tests, alphas):
    lines = ["# Evaluation summary", "", "```", json.dumps(stats, indent=1), "```", ""]
    cols = ["risk_out_mean", "risk_in_mean", "risk_out_max", "band_rel", "band_dice"]
    for a in alphas:
        lines += [f"## alpha = {a}", "",
                  "Test metrics, mean ± std over repartitions. "
                  "`risk_*_mean` is the random-rater risk.", "",
                  "| method | calibration target | " + " | ".join(cols) + " |",
                  "|---|---|" + "---|" * len(cols)]
        sub = summary[np.isclose(summary["alpha"], a)]
        for m in METHODS:
            for tg in TARGETS:
                r = sub[(sub.method == m) & (sub.target == tg)].iloc[0]
                cells = [f"{r[c + '_mean']:.3f} ± {r[c + '_std']:.3f}" for c in cols]
                lines.append(f"| {m} | {tg} | " + " | ".join(cells) + " |")
        lines.append("")
    lines += ["## Paired Wilcoxon test on per-unit band area (original split)", "",
              "| baseline | RACS band (px) | baseline band (px) | p |", "|---|---|---|---|"]
    for t in tests:
        lines.append(f"| {t['baseline']} | {t['racs_band_px']:.1f} | "
                     f"{t['baseline_band_px']:.1f} | {t['wilcoxon_p']:.2g} |")
    with open(os.path.join(out, "summary.md"), "w") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
