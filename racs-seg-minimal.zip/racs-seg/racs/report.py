"""Print a compact summary of an evaluation folder.

    python -m racs.report results/lidc_s0
"""
from __future__ import annotations

import json
import os
import sys

import pandas as pd


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 1:
        sys.exit(__doc__)
    d = argv[0]
    stats = json.load(open(os.path.join(d, "stats.json")))
    print({k: round(v, 3) if isinstance(v, float) else v for k, v in stats.items()})
    r = pd.read_csv(os.path.join(d, "results.csv"))
    r = r[r.target.isin(["raters_mean", "raters_max", "majority"])]
    r = r.sort_values(["target", "alpha", "method"])
    cols = ["method", "target", "alpha", "risk_out_mean_mean", "risk_in_mean_mean",
            "risk_out_max_mean", "band_rel_mean", "band_prec_mean",
            "band_rec_mean", "lambda_out_mean", "lambda_in_mean"]
    out = r[cols].round(3)
    out.columns = ["method", "target", "alpha", "risk_out", "risk_in",
                   "risk_out_max", "band_rel", "band_prec", "band_rec",
                   "lam_out", "lam_in"]
    print(out.to_string(index=False))
    print(pd.read_csv(os.path.join(d, "paired_tests.csv")).round(4).to_string(index=False))
    print(pd.read_csv(os.path.join(d, "ablation_ncal.csv")).round(3).to_string(index=False))


if __name__ == "__main__":
    main()
