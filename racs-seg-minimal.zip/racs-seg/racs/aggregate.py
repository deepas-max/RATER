"""Combine the results of several splits into the paper's tables and figures.

    python -m racs.aggregate results/final_s1 results/final_s2 results/final_s3 \
        --out results/final_combined

Writes (into --out):
    tables.md              all tables in Markdown, mean ± std across splits
    table_main.tex         rater-aware calibration, LaTeX (booktabs)
    table_consensus.tex    consensus versus rater-aware calibration, LaTeX
    combined_results.csv   every metric, mean and std across splits
    paired_tests.csv       per-split paired Wilcoxon tests
    fig_band.png           band size versus alpha, all methods
    fig_consensus.png      random-rater risk under each calibration target
    fig_paired.png         per-scan band at the middle alpha, per split
    fig_ncal.png           effect of the number of calibration scans
"""
from __future__ import annotations

import argparse
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

METHODS = ["racs", "dilation_sub", "dilation", "racs_s1", "prob"]
NAMES = {"racs": "RACS (proposed)", "dilation_sub": "Sub-pixel dilation",
         "dilation": "Uniform dilation", "racs_s1": "RACS, spread = 1",
         "prob": "Probability threshold"}
TARGET_NAMES = {"raters_mean": "Rater-aware (proposed)", "raters_max": "Rater-aware, worst rater",
                "majority": "Majority vote", "staple": "STAPLE", "one_rater": "One random rater"}
COLORS = {"racs": "#2a78d6", "dilation_sub": "#e87ba4", "dilation": "#eda100",
          "racs_s1": "#eb6834", "prob": "#1baf7a",
          "raters_mean": "#2a78d6", "majority": "#eb6834", "staple": "#1baf7a",
          "one_rater": "#eda100"}
MARKERS = {"racs": "o", "dilation_sub": "v", "dilation": "D", "racs_s1": "s", "prob": "^",
           "raters_mean": "o", "majority": "s", "staple": "^", "one_rater": "D"}
INK, MUTED, GRID = "#0b0b0b", "#52514e", "#e4e3df"
METRICS = ["risk_out_mean", "risk_in_mean", "risk_out_max", "risk_in_max",
           "band_rel", "band_prec", "band_rec", "band_px"]


def load(dirs):
    rows, paired, ncal, stats = [], [], [], []
    for k, d in enumerate(dirs, 1):
        r = pd.read_csv(os.path.join(d, "results.csv"))
        keep = ["method", "target", "alpha"] + [f"{m}_mean" for m in METRICS
                                                if f"{m}_mean" in r.columns]
        r = r[keep].copy()
        r.columns = [c[:-5] if c.endswith("_mean") and c[:-5] in METRICS else c
                     for c in r.columns]
        r["split"] = k
        rows.append(r)
        p = pd.read_csv(os.path.join(d, "paired_tests.csv"))
        p["split"] = k
        paired.append(p)
        n = pd.read_csv(os.path.join(d, "ablation_ncal.csv"))
        n["split"] = k
        ncal.append(n)
        s = json.load(open(os.path.join(d, "stats.json")))
        s["split"] = k
        stats.append(s)
    return (pd.concat(rows), pd.concat(paired), pd.concat(ncal), pd.DataFrame(stats))


def mean_std(df, keys, cols):
    g = df.groupby(keys)[cols]
    out = g.mean().add_suffix("_mean").join(g.std(ddof=1).add_suffix("_std"))
    return out.reset_index()


def fmt(m, s, d=3):
    return f"{m:.{d}f} ± {s:.{d}f}" if np.isfinite(s) else f"{m:.{d}f}"


def md_table(df, cols, header):
    lines = ["| " + " | ".join(header) + " |", "|" + "---|" * len(header)]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(str(r[c]) for c in cols) + " |")
    return "\n".join(lines)


def style(ax, xlabel, ylabel, title):
    ax.set_xlabel(xlabel, color=MUTED)
    ax.set_ylabel(ylabel, color=MUTED)
    ax.set_title(title, color=INK, loc="left", fontsize=11)
    ax.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(GRID)
    ax.tick_params(colors=MUTED, length=0)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument("dirs", nargs="+", help="result folders, one per split")
    p.add_argument("--out", required=True)
    args = p.parse_args(argv)
    os.makedirs(args.out, exist_ok=True)

    res, paired, ncal, stats = load(args.dirs)
    n_splits = len(args.dirs)
    metrics = [m for m in METRICS if m in res.columns]
    comb = mean_std(res, ["method", "target", "alpha"], metrics)
    comb.to_csv(os.path.join(args.out, "combined_results.csv"), index=False)
    paired.to_csv(os.path.join(args.out, "paired_tests.csv"), index=False)
    alphas = sorted(res.alpha.unique())
    a_mid = alphas[len(alphas) // 2]
    methods = [m for m in METHODS if m in res.method.unique()]

    md = [f"# Combined results over {n_splits} splits", "",
          "Values are mean ± standard deviation across splits. Within each split, "
          "every value is itself an average over 100 random calibration/test "
          "repartitions.", ""]

    # ---- dataset and network statistics --------------------------------
    sc = ["n_images", "n_cal_units", "n_test_units", "empty_mask_fraction",
          "dice_sdf_network", "dice_prob_network", "spread_spearman_mean"]
    sc = [c for c in sc if c in stats.columns]
    srow = [{"quantity": c, "value": fmt(stats[c].mean(), stats[c].std(ddof=1))} for c in sc]
    md += ["## Dataset and network statistics", "",
           md_table(pd.DataFrame(srow), ["quantity", "value"], ["Quantity", "Value"]), ""]

    # ---- main table: rater-aware calibration ---------------------------
    main_rows = []
    tex = [r"\begin{tabular}{llcccc}", r"\toprule",
           r"$\alpha$ & Method & Outer risk & Inner risk & Worst-rater outer risk & Band / union \\",
           r"\midrule"]
    for a in alphas:
        best = comb[(comb.target == "raters_mean") & (comb.alpha == a)].band_rel_mean.min()
        for m in methods:
            r = comb[(comb.method == m) & (comb.target == "raters_mean") & (comb.alpha == a)].iloc[0]
            main_rows.append({
                "alpha": a, "method": NAMES[m],
                "risk_out": fmt(r.risk_out_mean_mean, r.risk_out_mean_std),
                "risk_in": fmt(r.risk_in_mean_mean, r.risk_in_mean_std),
                "risk_out_max": fmt(r.risk_out_max_mean, r.risk_out_max_std),
                "band_rel": fmt(r.band_rel_mean, r.band_rel_std),
                "band_prec": fmt(r.band_prec_mean, r.band_prec_std) if "band_prec_mean" in r else "",
                "band_rec": fmt(r.band_rec_mean, r.band_rec_std) if "band_rec_mean" in r else ""})
            band = fmt(r.band_rel_mean, r.band_rel_std)
            if np.isclose(r.band_rel_mean, best):
                band = r"\textbf{" + band + "}"
            tex.append(f"{a:g} & {NAMES[m]} & {fmt(r.risk_out_mean_mean, r.risk_out_mean_std)} & "
                       f"{fmt(r.risk_in_mean_mean, r.risk_in_mean_std)} & "
                       f"{fmt(r.risk_out_max_mean, r.risk_out_max_std)} & {band} \\\\")
        tex.append(r"\midrule" if a != alphas[-1] else r"\bottomrule")
    tex.append(r"\end{tabular}")
    with open(os.path.join(args.out, "table_main.tex"), "w") as f:
        f.write("\n".join(tex).replace("±", r"$\pm$") + "\n")
    md += ["## Rater-aware calibration (mean over raters)", "",
           "Risks are for a random rater; the target is α. Band / union is the band "
           "area divided by the area of the union of rater masks (smaller is "
           "better). Precision is the share of the band inside the region where "
           "raters disagree; recall is the share of that region the band covers.", "",
           md_table(pd.DataFrame(main_rows),
                    ["alpha", "method", "risk_out", "risk_in", "risk_out_max",
                     "band_rel", "band_prec", "band_rec"],
                    ["α", "Method", "Outer risk", "Inner risk", "Worst-rater outer",
                     "Band / union", "Band precision", "Band recall"]), ""]

    # ---- consensus versus rater-aware calibration ----------------------
    targets = [t for t in ["raters_mean", "majority", "staple", "one_rater"]
               if t in res.target.unique()]
    cons_rows = []
    ctex = [r"\begin{tabular}{llccc}", r"\toprule",
            r"Method & Calibration target & $\alpha$ & Outer risk & Inner risk \\", r"\midrule"]
    for m in methods:
        for t in targets:
            for a in alphas:
                r = comb[(comb.method == m) & (comb.target == t) & (comb.alpha == a)].iloc[0]
                over = (r.risk_out_mean_mean > a) or (r.risk_in_mean_mean > a)
                cons_rows.append({"method": NAMES[m], "target": TARGET_NAMES[t], "alpha": a,
                                  "risk_out": fmt(r.risk_out_mean_mean, r.risk_out_mean_std),
                                  "risk_in": fmt(r.risk_in_mean_mean, r.risk_in_mean_std),
                                  "exceeds": "yes" if over else "no"})
                if m == "racs":
                    ro = fmt(r.risk_out_mean_mean, r.risk_out_mean_std)
                    ri = fmt(r.risk_in_mean_mean, r.risk_in_mean_std)
                    if r.risk_out_mean_mean > a:
                        ro = r"\textbf{" + ro + "}"
                    if r.risk_in_mean_mean > a:
                        ri = r"\textbf{" + ri + "}"
                    ctex.append(f"RACS & {TARGET_NAMES[t]} & {a:g} & {ro} & {ri} \\\\")
    ctex += [r"\bottomrule", r"\end{tabular}"]
    with open(os.path.join(args.out, "table_consensus.tex"), "w") as f:
        f.write("\n".join(ctex).replace("±", r"$\pm$") + "\n")
    md += ["## Random-rater risk under each calibration target", "",
           "\"Exceeds\" marks rows where either risk is above α.", "",
           md_table(pd.DataFrame(cons_rows),
                    ["method", "target", "alpha", "risk_out", "risk_in", "exceeds"],
                    ["Method", "Calibration target", "α", "Outer risk", "Inner risk",
                     "Exceeds α"]), ""]

    # ---- paired tests ---------------------------------------------------
    pt = paired.copy()
    pt["baseline"] = pt["baseline"].map(lambda b: NAMES.get(b, b))
    pt["reduction"] = 1 - pt.racs_band_px / pt.baseline_band_px
    prow = [{"split": int(r.split), "baseline": r.baseline,
             "racs": f"{r.racs_band_px:.1f}", "base": f"{r.baseline_band_px:.1f}",
             "red": f"{100 * r.reduction:.0f}%",
             "p": "< 0.0001" if r.wilcoxon_p < 1e-4 else f"{r.wilcoxon_p:.2g}"}
            for _, r in pt.iterrows()]
    md += [f"## Per-scan band at α = {a_mid:g}, paired Wilcoxon test", "",
           md_table(pd.DataFrame(prow), ["split", "baseline", "racs", "base", "red", "p"],
                    ["Split", "Baseline", "RACS band (px)", "Baseline band (px)",
                     "RACS smaller by", "p"]), ""]
    summ = pt.groupby("baseline")[["racs_band_px", "baseline_band_px", "reduction"]].mean()
    md += ["Mean over splits:", "",
           md_table(summ.reset_index().assign(
               r=lambda d: d.racs_band_px.map("{:.1f}".format),
               b=lambda d: d.baseline_band_px.map("{:.1f}".format),
               red=lambda d: (100 * d.reduction).map("{:.0f}%".format)),
               ["baseline", "r", "b", "red"],
               ["Baseline", "RACS band (px)", "Baseline band (px)", "RACS smaller by"]), ""]

    # ---- calibration size ----------------------------------------------
    nc = mean_std(ncal.drop(columns=[c for c in ncal.columns if c.endswith("_std")]),
                  ["n_cal"], ["risk_out_mean_mean", "risk_in_mean_mean", "band_px_mean"])
    nrow = [{"n": int(r.n_cal),
             "ro": fmt(r.risk_out_mean_mean_mean, r.risk_out_mean_mean_std),
             "ri": fmt(r.risk_in_mean_mean_mean, r.risk_in_mean_mean_std),
             "b": fmt(r.band_px_mean_mean, r.band_px_mean_std, 1)} for _, r in nc.iterrows()]
    md += [f"## Effect of the number of calibration scans (RACS, α = {a_mid:g})", "",
           md_table(pd.DataFrame(nrow), ["n", "ro", "ri", "b"],
                    ["Calibration scans", "Outer risk", "Inner risk", "Band (px)"]), ""]

    with open(os.path.join(args.out, "tables.md"), "w") as f:
        f.write("\n".join(md) + "\n")

    # ---- figures --------------------------------------------------------
    x = np.arange(len(alphas))
    off = np.linspace(-0.16, 0.16, len(methods))

    fig, ax = plt.subplots(figsize=(6.4, 4.2))
    for m, dx in zip(methods, off):
        s = comb[(comb.method == m) & (comb.target == "raters_mean")].sort_values("alpha")
        ax.errorbar(x + dx, s.band_rel_mean, yerr=s.band_rel_std, color=COLORS[m],
                    marker=MARKERS[m], markersize=7, linewidth=2, capsize=3, label=NAMES[m])
    ax.set_xticks(x)
    ax.set_xticklabels([f"{a:g}" for a in alphas])
    style(ax, "Target risk α", "Band area / union of rater masks",
          "Band size under rater-aware calibration (lower is better)")
    ax.legend(frameon=False, fontsize=9, labelcolor=INK)
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "fig_band.png"), dpi=300)
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4), sharey=True)
    toff = np.linspace(-0.12, 0.12, len(targets))
    for ax, col, title in zip(axes, ["risk_out_mean", "risk_in_mean"],
                              ["Outer boundary", "Inner boundary"]):
        for t, dx in zip(targets, toff):
            s = comb[(comb.method == "racs") & (comb.target == t)].sort_values("alpha")
            ax.errorbar(x + dx, s[f"{col}_mean"], yerr=s[f"{col}_std"], color=COLORS[t],
                        marker=MARKERS[t], markersize=7, linewidth=2, capsize=3,
                        label=TARGET_NAMES[t])
        ax.plot(x, alphas, color=MUTED, linestyle="--", linewidth=1.2, label="Target risk α")
        ax.set_xticks(x)
        ax.set_xticklabels([f"{a:g}" for a in alphas])
        style(ax, "Target risk α", "Test risk for a random rater", title)
    axes[0].legend(frameon=False, fontsize=9, labelcolor=INK)
    fig.suptitle("Calibrating on a consensus mask exceeds the target for individual raters",
                 x=0.01, ha="left", color=INK)
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "fig_consensus.png"), dpi=300)
    plt.close(fig)

    order = [NAMES[m] for m in ["dilation_sub", "dilation", "racs_s1", "prob"]
             if NAMES[m] in set(pt.baseline)]
    splits = sorted(pt.split.unique())
    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    w = 0.8 / (len(order) + 1)
    for j, sp in enumerate(splits):
        sub = pt[pt.split == sp]
        ax.bar(j - 0.4 + w / 2, sub.racs_band_px.iloc[0], w * 0.92, color=COLORS["racs"],
               label=NAMES["racs"] if j == 0 else None)
        for i, b in enumerate(order):
            key = [k for k, v in NAMES.items() if v == b][0]
            val = sub[sub.baseline == b].baseline_band_px.iloc[0]
            ax.bar(j - 0.4 + w * (i + 1.5), val, w * 0.92, color=COLORS[key],
                   label=b if j == 0 else None)
    ax.set_xticks(range(len(splits)))
    ax.set_xticklabels([f"Split {s}" for s in splits])
    style(ax, "", "Band per scan (pixels)",
          f"Per-scan band at α = {a_mid:g} (all differences p < 0.0001)"
          if (pt.wilcoxon_p < 1e-4).all() else f"Per-scan band at α = {a_mid:g}")
    ax.legend(frameon=False, fontsize=9, labelcolor=INK, ncol=3,
              loc="upper center", bbox_to_anchor=(0.5, -0.08))
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "fig_paired.png"), dpi=300)
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    xs = np.arange(len(nc))
    for col, name, c, mk in [("risk_out_mean_mean", "Outer risk", COLORS["racs"], "o"),
                             ("risk_in_mean_mean", "Inner risk", COLORS["racs_s1"], "s")]:
        axes[0].errorbar(xs, nc[f"{col}_mean"], yerr=nc[f"{col}_std"], color=c, marker=mk,
                         markersize=7, linewidth=2, capsize=3, label=name)
    axes[0].axhline(a_mid, color=MUTED, linestyle="--", linewidth=1.2, label="Target risk α")
    axes[1].errorbar(xs, nc.band_px_mean_mean, yerr=nc.band_px_mean_std, color=COLORS["racs"],
                     marker="o", markersize=7, linewidth=2, capsize=3)
    for ax in axes:
        ax.set_xticks(xs)
        ax.set_xticklabels(nc.n_cal.astype(int))
    style(axes[0], "Calibration scans", "Test risk for a random rater", "Risk stays below α")
    style(axes[1], "Calibration scans", "Band per scan (pixels)", "Band shrinks with more scans")
    axes[0].legend(frameon=False, fontsize=9, labelcolor=INK)
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "fig_ncal.png"), dpi=300)
    plt.close(fig)

    print("\n".join(md))
    print(f"\n[aggregate] wrote tables and figures to {args.out}")


if __name__ == "__main__":
    main()
