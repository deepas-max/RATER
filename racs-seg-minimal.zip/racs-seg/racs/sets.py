"""Score maps of each prediction-set family, and inference (Algorithm 3)."""
from __future__ import annotations

import numpy as np
import torch
from scipy.ndimage import distance_transform_edt

from .model import sdf_head

LOGIT_CLIP = 20.0


def racs_score(m, s):
    """Studentized signed distance t = m / s (the proposed family)."""
    return m / s


def prob_score(logit):
    """Probability thresholding: t = -logit, clipped to a bounded range."""
    return -np.clip(logit, -LOGIT_CLIP, LOGIT_CLIP)


def dilation_score(hard_mask):
    """Uniform dilation / erosion of a hard mask.

    t is the exact signed Euclidean distance of the mask, so {t <= lambda} is
    the dilation by a disk of radius lambda and {t < -lambda} the erosion.
    """
    mask = np.asarray(hard_mask).astype(bool)
    lam_max = float(np.hypot(*mask.shape))
    if not mask.any():
        return np.full(mask.shape, lam_max)
    if mask.all():
        return np.full(mask.shape, -lam_max)
    return distance_transform_edt(~mask) - distance_transform_edt(mask)


def subpixel_dilation_score(logit, factor: int = 4):
    """Dilation / erosion in sub-pixel steps.

    The logit map is upsampled bilinearly by `factor`, thresholded, and its
    signed Euclidean distance is averaged back to the original grid and
    expressed in original pixels. Unlike `dilation_score`, whose values jump
    in whole-pixel steps, this score can use the risk budget finely.
    """
    from scipy.ndimage import zoom
    logit = np.asarray(logit, dtype=np.float64)
    H, W = logit.shape
    lam_max = float(np.hypot(H, W))
    fine = zoom(logit, factor, order=1, mode="nearest", grid_mode=True) > 0
    if not fine.any():
        return np.full((H, W), lam_max)
    if fine.all():
        return np.full((H, W), -lam_max)
    sd = (distance_transform_edt(~fine) - distance_transform_edt(fine)) / factor
    sd -= np.sign(sd) * 0.5 / factor          # distance to the contour itself
    return sd.reshape(H, factor, W, factor).mean((1, 3))


def lam_max_of(method: str, shape, D: float, s_min: float) -> float:
    """Largest useful lambda of each family (outer set = image, inner = empty)."""
    return {
        "racs": D / s_min,
        "racs_s1": D,
        "prob": LOGIT_CLIP,
        "dilation": float(np.hypot(*shape)),
        "dilation_sub": float(np.hypot(*shape)),
    }[method]


@torch.no_grad()
def predict_sets(model, image, lam_out, lam_in, D=4.0, s_min=0.25,
                 device="cpu"):
    """Algorithm 3. `image` is a 2D array in [0, 1].

    lam_out may be negative (outer set inside the point prediction); it must
    satisfy lam_out >= -lam_in, which calibration enforces.

    Returns a dict with the inner region, outer region, band, the score map
    and the predicted mean / spread maps.
    """
    model.eval()
    x = torch.as_tensor(image, dtype=torch.float32, device=device)[None, None]
    m, s = sdf_head(model(x).float(), D, s_min)
    m, s = m[0].cpu().numpy().astype(np.float64), s[0].cpu().numpy().astype(np.float64)
    t = racs_score(m, s)
    outer = t <= lam_out
    inner = t < -lam_in
    return {"inner": inner, "outer": outer, "band": outer & ~inner,
            "score": t, "mean": m, "spread": s}
