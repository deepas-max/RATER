"""Figures for the paper, drawn from the evaluation summary."""
from __future__ import annotations

import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

from .model import sdf_head
from .sets import dilation_score, racs_score

INK, MUTED, GRID = "#0b0b0b", "#52514e", "#e4e3df"
COLORS = {"racs": "#2a78d6", "racs_s1": "#eb6834", "prob": "#1baf7a",
          "dilation": "#eda100", "dilation_sub": "#e87ba4", "raters_mean": "#2a78d6",
          "majority": "#eb6834", "staple": "#1baf7a", "one_rater": "#eda100"}
MARKERS = {"racs": "o", "racs_s1": "s", "prob": "^", "dilation": "D",
           "dilation_sub": "v",
           "raters_mean": "o", "majority": "s", "staple": "^", "one_rater": "D"}
LABELS = {"racs": "RACS (proposed)", "racs_s1": "RACS, spread = 1",
          "prob": "Probability threshold", "dilation": "Uniform dilation",
          "dilation_sub": "Sub-pixel dilation",
          "raters_mean": "Rater-aware (proposed)", "majority": "Majority vote",
          "staple": "STAPLE", "one_rater": "One random rater"}


def _style(ax, xlabel, ylabel, title):
    ax.set_xlabel(xlabel, color=MUTED)
    ax.set_ylabel(ylabel, color=MUTED)
    ax.set_title(title, color=INK, loc="left", fontsize=11)
    ax.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(GRID)
    ax.tick_params(colors=MUTED, length=0)


def _lines(ax, summary, series_col, series, fixed_col, fixed, ycol, alphas):
    offsets = np.linspace(-0.012, 0.012, len(series))
    for name, dx in zip(series, offsets):
        sub = summary[(summary[series_col] == name) & (summary[fixed_col] == fixed)]
        sub = sub.sort_values("alpha")
        x = np.arange(len(alphas)) + dx * 10
        ax.errorbar(x, sub[ycol + "_mean"], yerr=sub[ycol + "_std"],
                    color=COLORS[name], marker=MARKERS[name], markersize=7,
                    linewidth=2, capsize=3, label=LABELS[name])
    ax.set_xticks(np.arange(len(alphas)))
    ax.set_xticklabels([f"{a:g}" for a in alphas])


def _target_line(ax, alphas):
    ax.plot(np.arange(len(alphas)), alphas, color=MUTED, linestyle="--",
            linewidth=1.2, label="Target risk α")


def make_figures(out, summary, alphas, images, masks, sdf_model, prob_model,
                 cfg, lambdas, a_mid, device, test_idx, info):
    methods = ["racs", "racs_s1", "prob", "dilation", "dilation_sub"]
    targets = ["raters_mean", "majority", "staple", "one_rater"]

    # 1. Validity of every set family under rater-aware calibration.
    fig, axes = plt.subplots(1, 2, figsize=(10, 4), sharey=True)
    for ax, col, name in zip(axes, ["risk_out_mean", "risk_in_mean"],
                             ["Outer boundary", "Inner boundary"]):
        _lines(ax, summary, "method", methods, "target", "raters_mean", col, alphas)
        _target_line(ax, alphas)
        _style(ax, "Target risk α", "Test risk for a random rater", name)
    axes[0].legend(frameon=False, fontsize=9, labelcolor=INK)
    fig.suptitle("Rater-aware calibration keeps test risk at or below the target",
                 x=0.01, ha="left", color=INK)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "fig_validity.png"), dpi=200)
    plt.close(fig)

    # 2. Effect of the calibration target on the random-rater risk.
    fig, axes = plt.subplots(1, 2, figsize=(10, 4), sharey=True)
    for ax, col, name in zip(axes, ["risk_out_mean", "risk_in_mean"],
                             ["Outer boundary", "Inner boundary"]):
        _lines(ax, summary, "target", targets, "method", "racs", col, alphas)
        _target_line(ax, alphas)
        _style(ax, "Target risk α", "Test risk for a random rater", name)
    axes[0].legend(frameon=False, fontsize=9, labelcolor=INK)
    fig.suptitle("Random-rater risk of RACS sets, by calibration target",
                 x=0.01, ha="left", color=INK)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "fig_targets.png"), dpi=200)
    plt.close(fig)

    # 3. Efficiency and alignment.
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    _lines(axes[0], summary, "method", methods, "target", "raters_mean",
           "band_rel", alphas)
    _style(axes[0], "Target risk α", "Band area / union of rater masks",
           "Band size (lower is better)")
    _lines(axes[1], summary, "method", methods, "target", "raters_mean",
           "band_dice", alphas)
    _style(axes[1], "Target risk α", "Dice of band vs disagreement region",
           "Alignment with rater disagreement (higher is better)")
    axes[0].legend(frameon=False, fontsize=9, labelcolor=INK)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "fig_efficiency.png"), dpi=200)
    plt.close(fig)

    # 4. Qualitative overlays on test images with visible disagreement.
    key_r = f"racs|raters_mean|{a_mid}"
    key_d = f"dilation|raters_mean|{a_mid}"
    cand = test_idx[info["ndis"][test_idx] > 0]
    if len(cand) == 0 or key_r not in lambdas:
        return
    order = cand[np.argsort(info["ndis"][cand])]
    chosen = order[np.linspace(len(order) // 2, len(order) - 1, 6).astype(int)]
    x = torch.from_numpy(images[chosen])[:, None].to(device)
    with torch.no_grad():
        m, s = sdf_head(sdf_model(x).float(), cfg["D"], cfg["s_min"])
        logit = prob_model(x)[:, 0].float().cpu().numpy()
    m, s = m.cpu().numpy().astype(np.float64), s.cpu().numpy().astype(np.float64)

    fig, axes = plt.subplots(2, 6, figsize=(15, 5.4))
    for j, i in enumerate(chosen):
        scores = [racs_score(m[j], s[j]), dilation_score(logit[j] > 0)]
        for row, (t, key) in enumerate(zip(scores, [key_r, key_d])):
            ax = axes[row, j]
            ax.imshow(images[i], cmap="gray", vmin=0, vmax=1)
            for yk in masks[i]:
                if yk.any() and not yk.all():
                    ax.contour(yk, levels=[0.5], colors="white", linewidths=0.7)
            lam = lambdas[key]
            for region, color in [(t <= lam["lambda_out"], COLORS["racs"]),
                                  (t < -lam["lambda_in"], COLORS["racs_s1"])]:
                if region.any() and not region.all():
                    ax.contour(region, levels=[0.5], colors=color, linewidths=1.8)
            ax.set_xticks([])
            ax.set_yticks([])
    axes[0, 0].set_ylabel("RACS", color=INK)
    axes[1, 0].set_ylabel("Uniform dilation", color=INK)
    handles = [plt.Line2D([], [], color="#888", linewidth=1, label="Rater contours (white)"),
               plt.Line2D([], [], color=COLORS["racs"], linewidth=2, label="Outer boundary"),
               plt.Line2D([], [], color=COLORS["racs_s1"], linewidth=2, label="Inner boundary")]
    fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False)
    fig.suptitle(f"Prediction sets at α = {a_mid:g}", x=0.01, ha="left", color=INK)
    fig.tight_layout(rect=(0, 0.05, 1, 0.97))
    fig.savefig(os.path.join(out, "fig_qualitative.png"), dpi=200)
    plt.close(fig)
