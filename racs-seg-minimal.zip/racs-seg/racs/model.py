"""A plain 2D U-Net and the mean / spread output head."""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


def _block(cin, cout):
    return nn.Sequential(
        nn.Conv2d(cin, cout, 3, padding=1, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
        nn.Conv2d(cout, cout, 3, padding=1, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
    )


class UNet(nn.Module):
    """U-Net with `depth` down-sampling steps.

    Height and width of the input must be divisible by 2**depth.
    """

    def __init__(self, in_ch=1, out_ch=2, base=32, depth=4):
        super().__init__()
        self.depth = depth
        chans = [base * 2 ** i for i in range(depth + 1)]
        self.enc = nn.ModuleList()
        prev = in_ch
        for c in chans:
            self.enc.append(_block(prev, c))
            prev = c
        self.up = nn.ModuleList()
        self.dec = nn.ModuleList()
        for c in reversed(chans[:-1]):
            self.up.append(nn.ConvTranspose2d(prev, c, 2, stride=2))
            self.dec.append(_block(2 * c, c))
            prev = c
        self.head = nn.Conv2d(prev, out_ch, 1)

    def forward(self, x):
        f = 2 ** self.depth
        assert x.shape[-1] % f == 0 and x.shape[-2] % f == 0, (
            f"input size must be divisible by {f}, got {tuple(x.shape[-2:])}"
        )
        skips = []
        for i, enc in enumerate(self.enc):
            x = enc(x)
            if i < self.depth:
                skips.append(x)
                x = F.max_pool2d(x, 2)
        for up, dec in zip(self.up, self.dec):
            x = up(x)
            x = dec(torch.cat([x, skips.pop()], dim=1))
        return self.head(x)


def sdf_head(raw: torch.Tensor, D: float, s_min: float):
    """Map two raw channels to (m_hat, s_hat).

    m_hat lies in (-D, D); s_hat is at least s_min.
    """
    m = D * torch.tanh(raw[:, 0])
    s = s_min + F.softplus(raw[:, 1])
    return m, s
