"""Train the mean / spread network (mode 'sdf') or the probability baseline
(mode 'prob').

    python -m racs.train --data data/ --mode sdf  --out runs/lidc_sdf_s0
    python -m racs.train --data data/ --mode prob --out runs/lidc_prob_s0

Training resumes automatically from <out>/ckpt_last.pt, so an interrupted
Colab session can simply re-run the same command.
"""
from __future__ import annotations

import argparse
import json
import os
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from .data import TrainSet, load_dataset, split_groups
from .losses import beta_nll, dice_bce, racs_loss
from .model import UNet, sdf_head


def get_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument("--data", required=True,
                   help="'synthetic', a .npz file, or a LIDC pickle file/dir")
    p.add_argument("--out", required=True, help="output directory")
    p.add_argument("--mode", choices=["sdf", "prob"], default="sdf")
    p.add_argument("--epochs", type=int, default=100)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--base", type=int, default=32, help="U-Net base channels")
    p.add_argument("--depth", type=int, default=4)
    p.add_argument("--D", type=float, default=4.0,
                   help="distance truncation in pixels; keep it small so that a\n"
                        "rater with an empty mask cannot outweigh the others")
    p.add_argument("--s-min", type=float, default=0.25, help="spread floor")
    p.add_argument("--beta", type=float, default=0.5)
    p.add_argument("--gamma", type=float, default=1.0)
    p.add_argument("--tau", type=float, default=1.0)
    p.add_argument("--seed", type=int, default=0, help="training seed")
    p.add_argument("--split-seed", type=int, default=0,
                   help="seed of the patient split; keep fixed across runs")
    p.add_argument("--workers", type=int, default=2)
    p.add_argument("--no-augment", action="store_true")
    return p.parse_args(argv)


def build_model(cfg):
    out_ch = 2 if cfg["mode"] == "sdf" else 1
    return UNet(in_ch=1, out_ch=out_ch, base=cfg["base"], depth=cfg["depth"])


def compute_loss(model, batch, cfg, device, train=True):
    """Return (training loss, selection loss) for one batch."""
    x, mu, var, ybar = [b.to(device, non_blocking=True) for b in batch]
    raw = model(x)
    if cfg["mode"] == "sdf":
        m, s = sdf_head(raw.float(), cfg["D"], cfg["s_min"])
        loss = racs_loss(m, s, mu, var, ybar,
                         cfg["beta"], cfg["gamma"], cfg["tau"])
        # Model selection uses the plain NLL, which is a proper scoring rule.
        select = beta_nll(m, s, mu, var, beta=0.0)
    else:
        loss = dice_bce(raw[:, 0].float(), ybar)
        select = loss
    return loss, select


def main(argv=None):
    args = get_args(argv)
    cfg = {k.replace("-", "_"): v for k, v in vars(args).items()}
    os.makedirs(args.out, exist_ok=True)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    images, masks, groups = load_dataset(args.data)
    split = split_groups(groups, seed=args.split_seed)
    print(f"[train] images: train {len(split['train'])}, "
          f"val {len(split['val'])}, cal {len(split['cal'])}, "
          f"test {len(split['test'])}; device {device}")

    t0 = time.time()
    train_set = TrainSet(images[split["train"]], masks[split["train"]],
                         args.D, augment=not args.no_augment, seed=args.seed)
    val_set = TrainSet(images[split["val"]], masks[split["val"]],
                       args.D, augment=False)
    print(f"[train] rater statistics computed in {time.time() - t0:.0f}s")
    del images, masks

    train_loader = DataLoader(train_set, batch_size=args.batch_size,
                              shuffle=True, num_workers=args.workers,
                              drop_last=True, pin_memory=device == "cuda")
    val_loader = DataLoader(val_set, batch_size=args.batch_size,
                            shuffle=False, num_workers=args.workers)

    model = build_model(cfg).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)
    scaler = torch.amp.GradScaler(enabled=device == "cuda")
    start, best, history = 0, float("inf"), []

    last_path = os.path.join(args.out, "ckpt_last.pt")
    best_path = os.path.join(args.out, "ckpt_best.pt")
    if os.path.exists(last_path):
        ck = torch.load(last_path, map_location=device, weights_only=False)
        model.load_state_dict(ck["model"])
        opt.load_state_dict(ck["opt"])
        sched.load_state_dict(ck["sched"])
        start, best, history = ck["epoch"] + 1, ck["best"], ck["history"]
        print(f"[train] resumed from epoch {start}")

    with open(os.path.join(args.out, "config.json"), "w") as f:
        json.dump(cfg, f, indent=2)

    for epoch in range(start, args.epochs):
        model.train()
        t0, tot, n = time.time(), 0.0, 0
        for batch in train_loader:
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device, enabled=device == "cuda"):
                loss, _ = compute_loss(model, batch, cfg, device)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            tot += loss.item() * len(batch[0])
            n += len(batch[0])
        sched.step()

        model.eval()
        vtot, vn = 0.0, 0
        with torch.no_grad():
            for batch in val_loader:
                _, sel = compute_loss(model, batch, cfg, device, train=False)
                vtot += sel.item() * len(batch[0])
                vn += len(batch[0])
        val = vtot / max(vn, 1)
        history.append({"epoch": epoch, "train_loss": tot / max(n, 1),
                        "val_select": val})
        flag = ""
        if val < best:
            best = val
            torch.save({"model": model.state_dict(), "cfg": cfg,
                        "epoch": epoch, "val_select": val}, best_path)
            flag = " *"
        torch.save({"model": model.state_dict(), "opt": opt.state_dict(),
                    "sched": sched.state_dict(), "epoch": epoch,
                    "best": best, "history": history, "cfg": cfg}, last_path)
        with open(os.path.join(args.out, "history.json"), "w") as f:
            json.dump(history, f, indent=1)
        print(f"epoch {epoch + 1:3d}/{args.epochs}  "
              f"train {tot / max(n, 1):.4f}  val {val:.4f}  "
              f"{time.time() - t0:.0f}s{flag}", flush=True)

    print(f"[train] done. best val {best:.4f} -> {best_path}")


if __name__ == "__main__":
    main()
