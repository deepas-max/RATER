"""Rater-aware conformal risk calibration (Algorithm 2).

A prediction-set family is described by one score map t per image, where a
larger t means "further outside the lesion":

    outer set  O_lambda = { j : t_j <= lambda },  lambda in [-lam_max, lam_max]
    inner set  I_lambda = { j : t_j <  -lambda }, lambda in [0, lam_max]
    point prediction Y0 = { j : t_j < 0 }

The outer parameter may be negative: the outer set can then be smaller than
the point prediction. The inner set always stays inside the point prediction,
which keeps its loss bounded by one. After calibration the outer parameter is
raised, if needed, to lambda_out >= -lambda_in so that the inner set is
contained in the outer set.

Losses are evaluated on a fixed increasing grid of lambda values that ends at
lambda_max, where the outer set is the whole image and the inner set is empty.
Calibrating over a finite grid keeps the guarantee: the loss is still
monotone, and the chosen lambda is still the smallest feasible one in the set
of candidates.
"""
from __future__ import annotations

import numpy as np


def lambda_grid(lam_max: float, size: int = 300, power: float = 3.0):
    """Grid on [0, lam_max], denser near zero for power > 1."""
    return lam_max * np.linspace(0.0, 1.0, size) ** power


def signed_grid(grid: np.ndarray) -> np.ndarray:
    """Mirror a grid on [0, lam_max] to an increasing grid on [-lam_max, lam_max].

    Used for the outer set, which may shrink inside the point prediction when
    the risk budget allows it (negative lambda).
    """
    return np.concatenate([-grid[:0:-1], grid])


def nested_outer_index(outer_grid, g_out: int, lam_in: float) -> int:
    """Smallest outer index >= g_out whose set contains the inner set.

    {t < -lam_in} is inside {t <= lam_out} whenever lam_out >= -lam_in.
    Raising the outer index only lowers the outer loss, so the outer
    guarantee is kept.
    """
    return max(int(g_out), int(np.searchsorted(outer_grid, -lam_in, side="left")))


def outer_loss_curve(t, y, grid):
    """Fraction of mask y left outside O_lambda, for every lambda in grid."""
    n = int(y.sum())
    if n == 0:
        return np.zeros(len(grid))
    v = np.sort(t[y])
    return 1.0 - np.searchsorted(v, grid, side="right") / n


def inner_loss_curve(t, y, grid):
    """|I_lambda minus y| divided by |Y0|, for every lambda in grid."""
    n0 = int((t < 0).sum())
    if n0 == 0:
        return np.zeros(len(grid))
    v = np.sort(t[~y])
    return np.searchsorted(v, -grid, side="left") / n0


def outer_count_curve(t, grid, region=None):
    """|O_lambda| (optionally intersected with a region) along the grid."""
    v = np.sort(t[region] if region is not None else t.ravel())
    return np.searchsorted(v, grid, side="right").astype(np.float64)


def inner_count_curve(t, grid, region=None):
    """|I_lambda| (optionally intersected with a region) along the grid."""
    v = np.sort(t[region] if region is not None else t.ravel())
    return np.searchsorted(v, -grid, side="left").astype(np.float64)


def aggregate(losses: np.ndarray, how: str = "mean"):
    """Aggregate per-rater loss curves [K, G] into one curve [G]."""
    if how == "mean":
        return losses.mean(0)
    if how == "max":
        return losses.max(0)
    raise ValueError(f"unknown aggregator {how!r}")


def crc_index_from_mean(mean_curve: np.ndarray, n: int, alpha: float) -> int:
    """Same as `crc_index`, from the mean calibration loss curve [G]."""
    if alpha < 1.0 / (n + 1):
        raise ValueError(
            f"alpha={alpha} is below 1/(n+1)={1 / (n + 1):.4f}; "
            "use more calibration units or a larger alpha"
        )
    risk = n / (n + 1) * mean_curve + 1.0 / (n + 1)
    ok = risk <= alpha
    if not ok[-1]:
        raise ValueError("loss is not zero at lambda_max; check the scores")
    return int(np.argmax(ok))


def crc_index(cal_losses: np.ndarray, alpha: float) -> int:
    """Conformal risk control over a grid.

    cal_losses: [n, G] losses of n exchangeable calibration units, bounded by
    1 and non-increasing along the grid, with the last column equal to zero.
    Returns the smallest grid index g such that
        n / (n + 1) * mean_i L_i(g) + 1 / (n + 1) <= alpha.
    """
    return crc_index_from_mean(cal_losses.mean(0), cal_losses.shape[0], alpha)


def calibrate(cal_losses: np.ndarray, grid: np.ndarray, alpha: float) -> float:
    """Return lambda_hat for calibration losses [n, G] on `grid`."""
    return float(grid[crc_index(cal_losses, alpha)])
