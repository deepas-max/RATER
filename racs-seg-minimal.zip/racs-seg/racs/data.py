"""Datasets, signed distances, rater statistics and patient-level splits.

All datasets are held in memory as three arrays:
    images : float32 [N, H, W], values in [0, 1]
    masks  : uint8   [N, K, H, W], one binary mask per rater
    groups : array   [N], patient (or scan) identifier of each image
"""
from __future__ import annotations

import os
import pickle
import re

import numpy as np
import torch
from scipy.ndimage import distance_transform_edt
from torch.utils.data import Dataset, get_worker_info


# --------------------------------------------------------------------------
# Signed distance and rater statistics
# --------------------------------------------------------------------------
def signed_distance(mask: np.ndarray, D: float) -> np.ndarray:
    """Truncated signed Euclidean distance: negative inside, positive outside.

    An empty mask gives +D everywhere and a full mask gives -D everywhere.
    """
    mask = np.asarray(mask).astype(bool)
    if not mask.any():
        return np.full(mask.shape, D, dtype=np.float32)
    if mask.all():
        return np.full(mask.shape, -D, dtype=np.float32)
    outside = distance_transform_edt(~mask)
    inside = distance_transform_edt(mask)
    return np.clip(outside - inside, -D, D).astype(np.float32)


def rater_stats(masks: np.ndarray, D: float):
    """Per-pixel mean and variance over raters of the signed distance.

    Returns (mu, var, ybar), each float16 [N, H, W]. `ybar` is the rater-mean
    mask. Only these three maps are needed for training, because
        mean_k (phi_k - m)^2 = (m - mu)^2 + var.
    """
    N, K, H, W = masks.shape
    mu = np.empty((N, H, W), dtype=np.float16)
    var = np.empty((N, H, W), dtype=np.float16)
    ybar = np.empty((N, H, W), dtype=np.float16)
    for i in range(N):
        phi = np.stack([signed_distance(masks[i, k], D) for k in range(K)])
        mu[i] = phi.mean(0)
        var[i] = phi.var(0)
        ybar[i] = masks[i].mean(0)
    return mu, var, ybar


# --------------------------------------------------------------------------
# Loaders
# --------------------------------------------------------------------------
def load_lidc_pickle(path: str):
    """Load the preprocessed LIDC-IDRI crops used by Probabilistic U-Net code.

    `path` is a pickle file or a directory of pickle files. Each entry is a
    dict with keys 'image' (2D array in [0, 1]), 'masks' (list of 4 binary
    arrays) and 'series_uid'. Images are grouped by patient id when the entry
    key contains one (LIDC-IDRI-XXXX), otherwise by series_uid.
    """
    files = [path]
    if os.path.isdir(path):
        files = sorted(
            os.path.join(path, f) for f in os.listdir(path) if ".pickle" in f
        )
    if not files:
        raise FileNotFoundError(f"No pickle files found in {path}")
    data = {}
    for f in files:
        with open(f, "rb") as fh:
            data.update(pickle.load(fh))

    keys = list(data.keys())
    first = data[keys[0]]
    H, W = np.asarray(first["image"]).shape
    K = len(first["masks"])
    images = np.empty((len(keys), H, W), dtype=np.float32)
    masks = np.empty((len(keys), K, H, W), dtype=np.uint8)
    patient, series = [], []
    for i, key in enumerate(keys):
        value = data.pop(key)          # free each entry as it is copied
        images[i] = value["image"]
        for k in range(K):
            masks[i, k] = np.asarray(value["masks"][k]) > 0.5
        match = re.search(r"LIDC-IDRI-\d+", str(key))
        patient.append(match.group(0) if match else None)
        series.append(str(value["series_uid"]))
    if all(p is not None for p in patient):
        groups, how = np.asarray(patient), "patient id"
    else:
        groups, how = np.asarray(series), "series_uid (one group per scan)"
    print(f"[data] LIDC: {len(images)} images of {H}x{W}, {K} raters, "
          f"{len(np.unique(groups))} groups, grouped by {how}")
    return images, masks, groups


def load_npz(path: str):
    """Load a generic dataset saved with np.savez(images=, masks=, groups=)."""
    z = np.load(path, allow_pickle=False)
    images = z["images"].astype(np.float32)
    masks = (z["masks"] > 0.5).astype(np.uint8)
    groups = z["groups"]
    assert images.ndim == 3 and masks.ndim == 4 and len(groups) == len(images)
    return images, masks, groups


def make_synthetic(n_patients=400, per_patient=3, size=64, K=4, seed=0,
                   p_empty=0.03):
    """Synthetic lesions whose boundary is ambiguous on one angular sector.

    Raters agree closely (std 0.5 px) on the sharp part of the boundary and
    disagree (std about 3.5 px) on the blurred sector. The blur is visible in
    the image, so a network can learn where raters will disagree.
    """
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[:size, :size].astype(np.float32)
    N = n_patients * per_patient
    images = np.empty((N, size, size), dtype=np.float32)
    masks = np.zeros((N, K, size, size), dtype=np.uint8)
    groups = np.repeat(np.arange(n_patients), per_patient)

    def sigmoid(x):
        return 1.0 / (1.0 + np.exp(-x))

    for i in range(N):
        cx, cy = rng.uniform(0.38, 0.62, 2) * size
        r0 = rng.uniform(0.13, 0.24) * size
        phase = rng.uniform(0, 2 * np.pi)
        theta0 = rng.uniform(0, 2 * np.pi)
        width = rng.uniform(0.6, 1.6)
        angle = np.arctan2(yy - cy, xx - cx)
        radius = r0 * (1 + 0.15 * np.cos(2 * (angle - phase)))
        dist = np.hypot(xx - cx, yy - cy) - radius
        dang = np.abs(np.angle(np.exp(1j * (angle - theta0))))
        amb = sigmoid((width - dang) / 0.15)
        blur = 1.0 + 5.0 * amb
        img = 0.25 + 0.5 * sigmoid(-dist / blur)
        img += rng.normal(0, 0.05, img.shape)
        images[i] = np.clip(img, 0, 1)
        for k in range(K):
            if rng.random() < p_empty:
                continue
            shift = rng.normal(0, 0.5) + amb * rng.normal(0, 3.5)
            masks[i, k] = dist < shift
    return images, masks, groups


def load_dataset(spec: str):
    """`spec` is 'synthetic', 'synthetic:<n_patients>', a .npz file, or a
    LIDC pickle file / directory."""
    if spec.startswith("synthetic"):
        n = int(spec.split(":")[1]) if ":" in spec else 400
        return make_synthetic(n_patients=n)
    if spec.endswith(".npz"):
        return load_npz(spec)
    return load_lidc_pickle(spec)


# --------------------------------------------------------------------------
# Splits
# --------------------------------------------------------------------------
def split_groups(groups, seed=0, fractions=(0.6, 0.2, 0.2), val_frac=0.1):
    """Split image indices by group into train / val / cal / test.

    `fractions` are the train, calibration and test shares of the groups.
    `val_frac` of the training groups are held out for model selection.
    The split depends only on (groups, seed), so training and evaluation
    scripts recover the same split.
    """
    groups = np.asarray(groups)
    uniq = np.unique(groups)
    rng = np.random.default_rng(seed)
    perm = rng.permutation(len(uniq))
    n_train = int(round(fractions[0] * len(uniq)))
    n_cal = int(round(fractions[1] * len(uniq)))
    n_val = max(1, int(round(val_frac * n_train)))
    parts = {
        "val": uniq[perm[:n_val]],
        "train": uniq[perm[n_val:n_train]],
        "cal": uniq[perm[n_train:n_train + n_cal]],
        "test": uniq[perm[n_train + n_cal:]],
    }
    return {k: np.flatnonzero(np.isin(groups, v)) for k, v in parts.items()}


# --------------------------------------------------------------------------
# Training dataset
# --------------------------------------------------------------------------
class TrainSet(Dataset):
    """Images with precomputed rater statistics, with optional augmentation.

    Flips and 90-degree rotations are exact symmetries of the signed distance,
    so the statistics are transformed together with the image and never need
    to be recomputed.
    """

    def __init__(self, images, masks, D, augment=True, seed=0):
        self.images = images
        self.mu, self.var, self.ybar = rater_stats(masks, D)
        self.augment = augment
        self.rng = np.random.default_rng(seed)
        self._worker_rng = None

    def _rng(self):
        """Random generator for augmentation.

        DataLoader workers are re-created every epoch from a copy of this
        object, so each worker builds its own generator from the seed PyTorch
        assigns it. Otherwise every epoch would repeat the same augmentations.
        """
        info = get_worker_info()
        if info is None:
            return self.rng
        if self._worker_rng is None:
            self._worker_rng = np.random.default_rng(info.seed)
        return self._worker_rng

    def __len__(self):
        return len(self.images)

    def __getitem__(self, i):
        x = np.stack([
            self.images[i],
            self.mu[i].astype(np.float32),
            self.var[i].astype(np.float32),
            self.ybar[i].astype(np.float32),
        ])
        if self.augment:
            rng = self._rng()
            if rng.random() < 0.5:
                x = x[:, :, ::-1]
            if rng.random() < 0.5:
                x = x[:, ::-1, :]
            x = np.rot90(x, int(rng.integers(4)), axes=(1, 2))
            x = np.ascontiguousarray(x)
            gain = rng.uniform(0.9, 1.1)
            bias = rng.uniform(-0.05, 0.05)
            x[0] = np.clip(x[0] * gain + bias, 0, 1)
        x = torch.from_numpy(np.ascontiguousarray(x))
        return x[0:1], x[1], x[2], x[3]
