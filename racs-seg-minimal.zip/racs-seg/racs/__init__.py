"""RACS: Rater-Aware Conformal Segmentation."""

__version__ = "1.0.0"
