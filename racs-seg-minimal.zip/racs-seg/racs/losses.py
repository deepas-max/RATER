"""Training losses (Algorithm 1)."""
from __future__ import annotations

import torch
import torch.nn.functional as F


def beta_nll(m, s, mu, var, beta=0.5):
    """Gaussian negative log-likelihood averaged over raters and pixels.

    Uses mean_k (phi_k - m)^2 = (m - mu)^2 + var. With beta > 0 each pixel is
    weighted by stop_gradient(s^(2 beta)) (Seitzer et al., 2022), which stops
    the spread head from down-weighting hard pixels. beta = 0 is the plain NLL.
    """
    nll = ((m - mu) ** 2 + var) / (2 * s ** 2) + torch.log(s)
    if beta > 0:
        nll = nll * (s.detach() ** (2 * beta))
    return nll.mean()


def dice_bce(logits, target, eps=1.0):
    """Soft Dice plus binary cross-entropy against a soft target in [0, 1]."""
    p = torch.sigmoid(logits)
    dims = (1, 2)
    inter = (p * target).sum(dims)
    dice = 1 - (2 * inter + eps) / (p.sum(dims) + target.sum(dims) + eps)
    bce = F.binary_cross_entropy_with_logits(logits, target)
    return dice.mean() + bce


def racs_loss(m, s, mu, var, ybar, beta=0.5, gamma=1.0, tau=1.0):
    """L = L_NLL + gamma * L_seg, with the soft mask sigmoid(-m / tau)."""
    return beta_nll(m, s, mu, var, beta) + gamma * dice_bce(-m / tau, ybar)
