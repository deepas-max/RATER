"""Consensus masks and small metrics."""
from __future__ import annotations

import numpy as np


def majority_vote(masks: np.ndarray) -> np.ndarray:
    """Pixels marked by at least half of the raters. masks: [K, H, W]."""
    return masks.mean(0) >= 0.5


def staple(masks: np.ndarray, iters: int = 50, tol: float = 1e-6):
    """Binary STAPLE (Warfield et al., 2004) for one image.

    masks: [K, H, W] binary. Returns the consensus mask (posterior >= 0.5).
    Sensitivities and specificities are initialised at 0.9 and the prior is
    the mean foreground fraction over raters.
    """
    K = masks.shape[0]
    d = masks.reshape(K, -1).astype(np.float64)
    prior = d.mean()
    if prior == 0:
        return np.zeros(masks.shape[1:], dtype=bool)
    if prior == 1:
        return np.ones(masks.shape[1:], dtype=bool)
    p = np.full(K, 0.9)
    q = np.full(K, 0.9)
    w = d.mean(0)
    for _ in range(iters):
        a = prior * np.prod(np.where(d == 1, p[:, None], 1 - p[:, None]), 0)
        b = (1 - prior) * np.prod(np.where(d == 0, q[:, None], 1 - q[:, None]), 0)
        w_new = a / np.maximum(a + b, 1e-300)
        p = (d * w_new).sum(1) / max(w_new.sum(), 1e-12)
        q = ((1 - d) * (1 - w_new)).sum(1) / max((1 - w_new).sum(), 1e-12)
        p, q = np.clip(p, 1e-6, 1 - 1e-6), np.clip(q, 1e-6, 1 - 1e-6)
        done = np.abs(w_new - w).max() < tol
        w = w_new
        if done:
            break
    return (w >= 0.5).reshape(masks.shape[1:])


def dice(a: np.ndarray, b: np.ndarray) -> float:
    """Dice overlap of two binary masks; 1.0 when both are empty."""
    a, b = a.astype(bool), b.astype(bool)
    denom = a.sum() + b.sum()
    return 1.0 if denom == 0 else 2.0 * (a & b).sum() / denom
